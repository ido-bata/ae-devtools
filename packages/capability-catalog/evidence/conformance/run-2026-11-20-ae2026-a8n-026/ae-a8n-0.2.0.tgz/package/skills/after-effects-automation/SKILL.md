---
name: after-effects-automation
description: Drive a real Adobe After Effects from Node with @ido-bata/ae-a8n — open a project, apply an effect by match name, set parameters, render a frame to PNG, and verify the pixels — without damaging anyone's open work. Use when a task needs After Effects itself to do something or to prove a plugin/effect behaves, not just to read or write .aep-adjacent files.
---

# Driving After Effects with ae-a8n

`@ido-bata/ae-a8n` runs ExtendScript inside a real After Effects and gives you
a typed API over it. Everything below matches the package's public types; if
a call you want is not listed here, check `dist/index.d.ts` rather than guess —
there is, for example, **no save and no arbitrary-script API**.

Verified on macOS (After Effects 2026 / 26.5, Japanese UI). **Windows has not
been run at all**; on Windows the package will not quit After Effects for you
(ownership is always `unknown` there).

## Rules that are not optional

1. **Never kill After Effects** (`kill`, `pkill`, Force Quit) unless the human
   said so for that process. A killed AE shows a crash-recovery dialog on the
   next launch that only a person can dismiss.
2. **Work on a copy** of any `.aep`. Never open a production project.
3. **If After Effects was already running, it is not yours.** `ownership()`
   tells you; do not open projects in an `attached` or `unknown` session.
   Report it and ask the human to quit AE instead.
4. **Discard only your own edits.** Pass `{ unsavedChanges: "discard" }` only
   to `close()` / `openProject()` of a session you own, about changes you made.
5. **One session at a time.** After Effects is single-instance; do not run two
   scripts that launch it concurrently.
6. **Do not leave long-running work inside AE.** A script that runs for
   seconds lets other installed extensions run inside it; one has been seen to
   raise a modal alert that blocks AE until a person clicks it.

## macOS: UIフォーカスとモーダルダイアログ

- **普段のmacOSユーザーでGUI操作をフォールバックしない。** Aeがモーダルで止まっても、システム全体のカーソル移動、`osascript`のGUIクリック、CGEvent、Accessibility操作で物理デスクトップを乗っ取らない。タイムアウトしたら状態と証跡を残して停止する。
- 隔離実行は別のOSユーザーのGUIセッション（別フレームバッファ・別HID）で行う。`offstage` の session lane がその代表で、[docs/offstage-macos.md](https://github.com/ido-bata/ae-a8n/blob/main/docs/offstage-macos.md) と #49 を参照。**macOS実機の受入とトランスポートのセッション宛先確認が終わるまで、本番の標準経路として扱わない。**
- `offstage` の `session setup` は `sudo` と端末を必要とするため**人間が実行する**。TCCデータベースの直接書き込みやSIPの無効化は**自動では行わない**。
- ライセンス上、同じMacの別ユーザーは追加のデバイス認証にカウントされないが、Adobeアプリを使うOSユーザーは同時に1人だけ。自動サインアウト、ライセンス上限ダイアログの勝手な処理は禁止。

## Before you start

```bash
pgrep -lx "After Effects"        # macOS: anything listed is someone's session
```

```ts
import { resolveInstall } from "@ido-bata/ae-a8n";
const install = resolveInstall(); // throws AfterEffectsNotInstalledError if none
```

After Effects must have **Settings → Scripting & Expressions → Allow Scripts
to Write Files and Access Network** enabled (General in older versions).
Without it the first call times out after the readiness budget instead of
failing fast.

## The session

```ts
import { AfterEffects } from "@ido-bata/ae-a8n";

const ae = await AfterEffects.launch({ timeoutMs: 120_000 }); // per-call budget; default 30 s
ae.info();       // { version: "26.5x89", build: "89" } from the readiness probe
ae.ownership();  // { kind: "owned" | "attached" | "unknown", evidence: string }
```

- A cold launch can take long; the readiness probe has its own 180 s budget.
  One cold launch has been observed at 171 s.
- `owned`: this session started AE and it is still that process. Only then
  does `close()` quit it.
- `attached`: AE was running before. `close()` leaves it alone.
- `unknown`: no evidence either way (every Windows session, or the process
  was replaced). Treated like `attached`.

## Doing the work

```ts
const project = await ae.openProject("/tmp/work/copy-of-fixture.aep");
const comp = await project.comp("Main");          // EntityNotFoundError if absent
const layer = await comp.layer("Solid 1");
const effect = await layer.effects.apply("ADBE Gaussian Blur 2");
const blur = effect.parameter("ADBE Gaussian Blur 2-0001");
await blur.set(60);       // returns the value AE now holds
await blur.get();         // read back; plugins may clamp
```

- **Project paths must be absolute** (`/…`, `C:\…`, `\\server\share\…`).
  After Effects resolves a relative path against its own working directory,
  not yours, so `openProject` rejects one with a `TypeError` before sending
  anything. Resolve it yourself: `path.resolve("copy.aep")`, or `"$PWD/copy.aep"`
  in a shell.
- **Use match names**, not display names. Display names are localised
  (Gaussian Blur's "Blurriness" is "ブラー" in a Japanese UI); match names are
  not. Find them from what AE reports:
  `await layer.effects.all()` → `{ name, matchName }[]`,
  `await effect.parameters()` → `{ name, matchName, kind, valueType?, value? }[]`.
- Every property has a `kind`, and a `value` only when `kind` is `"value"`.
  The others have nothing a script can read or write: `"no-value"` (e.g.
  Tint's nameless `ADBE Tint-0004`), `"custom-value"` (Levels' histogram,
  Curves) and `"group"` (every effect's Compositing Options). `get()` and
  `set()` on them reject with `PropertyHasNoValueError` (its `kind` says
  which) and write nothing; `info()` describes them without failing. (In
  0.1.0-alpha.0 such a property made `parameters()` fail for the whole
  effect.)
- A `"value"` property's `valueType` says what its `value` is: a number for
  `OneD` (sliders, checkboxes, angles, dropdowns), `LAYER_INDEX` and
  `MASK_INDEX`; `[x, y]` for `TwoD_SPATIAL` (points); `[x, y, z]` for
  `ThreeD_SPATIAL`; `[r, g, b, a]` (0–1) for `COLOR`. `set()` takes the same
  shapes (a 3D point also takes `[x, y]`, a colour also `[r, g, b]`); any
  other shape rejects with `ParameterValueError` and writes nothing. (After
  Effects itself would store 0 for `[]` on a number.) Values come back in
  single precision: `0.2` reads back as `0.20000000298023`.
- A parameter identifier the effect does not have fails with "parameter not
  found", an `AfterEffectsError` rather than `EntityNotFoundError` (#24).
- To use an effect that should already be on the layer, look it up with
  `layer.effects.get(id)`: it throws `EntityNotFoundError` if the effect is
  not there. `effects.apply(id)` returns the existing effect if the layer
  already has one with that name or match name, and **adds one** if not, so
  a misspelt identifier passed to `apply()` adds an effect.
- Defaults are AE's, not zero: Gaussian Blur's Blurriness defaults to 25.
- Built-in effects can have options that confine a change. Gaussian Blur's
  "Repeat Edge Pixels" (`ADBE Gaussian Blur 2-0003`) defaults on and keeps
  the blur inside the layer's bounds: pixels outside the layer never change,
  and on a uniform solid only a thin band just inside its edges does
  (observed: 79,212 of 2,073,600 pixels between blur 0 and 100, alpha
  255 → 253 at the edge). Compare the whole image, not one sample point, or
  turn the option off (`0`) to let the blur spread past the layer.

## Rendering and checking pixels

```ts
const before = await comp.renderFrame(0, { subdirectory: "before" });
await blur.set(100);
const after = await comp.renderFrame(0, { subdirectory: "after" });
// { path, frame, width, height } — size read from the PNG that was written
```

- `frame` is a frame index (time = frame × frame duration).
- Files land in `ae.artifactsDir[/subdirectory]/<prefix or comp>.<00000>.png`.
- Output is 8-bit RGBA at full comp resolution; outside the layers alpha is 0.
- Compare files by hash *and* by pixels. `examples/png.ts` in this package
  has a dependency-free reader and `countChangedPixels`.
- Compare renders from the same session. The same frame of the same project
  can come out ±1 in one channel on soft edges in a different After Effects
  session (observed: 13 pixels on a blurred edge, #25), so a hash or exact
  pixel match against another session's file can fail spuriously; allow a
  tolerance there.
- Rendering marks the project as changed (the viewer resolution is forced to
  full and restored), so plan to close with `discard`.

## Closing

```ts
const result = await ae.close({ unsavedChanges: "discard" }); // only for your own edits
// { quit: boolean, ownership, reason? }
```

- With unsaved changes and no `discard`, `close()` throws
  `UnsavedChangesError` and the session stays open — decide, then retry.
- `quit: false` with a `reason` means AE was left running on purpose.
- Then check: `pgrep -lx "After Effects"` should print nothing if you owned
  it, and `pgrep -l osascript` should be empty.
- After Effects helper processes (`crashpad_handler`, `dynamiclinkmanager`,
  `TeamProjectsLocalHub`) can stay up for seconds to minutes after AE has
  quit, and exit on their own. `pgrep -f "After Effects"` matches them; they
  are not a running After Effects. Do not wait on them or kill them.

## When something goes wrong

| Error | Meaning | Do |
| --- | --- | --- |
| `EntityNotFoundError` (`kind`) | comp/layer/effect name not in the project | list with `comps()`, `layers()`, `effects.all()` |
| `ParameterValueError` (`valueType`) | `set()` value of the wrong shape for the property; nothing was written | check `valueType` in `info()` and pass that shape |
| `PropertyHasNoValueError` (`kind`) | get/set on a property without a value; nothing was written | pick a `kind: "value"` property from `parameters()` |
| `UnsavedChangesError` | would discard unsaved work | if it is yours, retry with `discard`; else stop |
| `AfterEffectsError` | AE reported a failure; message has AE's text | read `error.message` and `error.cause` |
| `TimeoutError` (as `cause`) | no answer within the budget | see below — the work may still be running |
| `AfterEffectsNotInstalledError` | no install found | pass `installDir` or stop |

Launcher messages carry osascript's own error code: `-1728` the application
path did not resolve, `-609` AE was quitting, `-1712` the AppleEvent itself
timed out (AE blocked, often by a dialog).

**Evidence.** `ae.tracePath` is a JSON-lines file: one record per operation
with `op`, `status` (`ok`/`error`/`timeout`), `durationMs`, `args`, `result`
or `error`. `ae.traceEvents` is the same in memory. The session directory
(`dirname(ae.tracePath)`) also holds every request and result envelope
(`inbox/`, `outbox/`) and renders (`artifacts/`). Read these before
re-running anything. A failed operation currently appears twice in the trace
(#20); count failures by `seq` pairs, not rows.

## After a timeout

An ExtendScript cannot be interrupted. A timeout ends *your wait*, not the
work:

- The script keeps running in AE and its effects land anyway.
- The next call waits for it (within its own budget) before sending.
- Nothing is retried for you. Before retrying, **read the state back**
  (`effects.all()`, `parameter.get()`); the operations above are written to
  be repeatable, but your own sequence may not be.
- The session's `timeoutMs` is the default for every call, and it includes
  the bridge's own overhead, not only the time inside AE. Opening a small
  project took 330–510 ms inside AE, so a budget under about a second can
  time out on `openProject` alone. Give the slow calls their own budget
  instead of raising the session's: `openProject(path, { timeoutMs })`,
  `renderFrame(frame, { timeoutMs })`, `ae.project({ timeoutMs })`. How long a
  timed-out call really took inside AE is `durationMs` in its
  `outbox/<id>.result.json`; do not add up your waits.
- A timed-out `openProject` still opens the project in AE, but gives you no
  `Project`. Get one with `await ae.project()`: it waits for the open to
  finish, opens nothing, and `(await project.info()).file` tells you which
  project it is. Do not call `openProject` again for this; after edits that
  raises `UnsavedChangesError`, and passing `discard` to get past it throws
  your work away.
- If calls keep timing out, AE is probably blocked by a modal dialog. Scripts
  cannot dismiss it. Stop, tell the human what you saw (trace + the last
  error), and do not kill AE.

## Not covered

Saving projects, expressions, keyframes, render queue output modules, audio,
Windows behaviour. Creating a comp and adding a text layer **are** covered
(`project.createComp(...)`, `comp.addTextLayer(...)`); do not improvise the
rest through other channels without the human's agreement.

## Worked examples

In the package (`node_modules/@ido-bata/ae-a8n/examples/`) and the repository:

- `examples/inspect.ts` — install, ownership, project listing; touches nothing.
- `examples/render-compare.ts` — apply, set, render before/after, count
  changed pixels, close.

Node will not run `.ts` files from inside `node_modules`; copy `examples/`
into your own directory first, then run them with a Node that executes
TypeScript directly (Node 24 does):

```bash
node examples/render-compare.ts "$PWD/copy.aep" Main "Solid 1" \
  "ADBE Gaussian Blur 2" "ADBE Gaussian Blur 2-0001" 0 100 "ADBE Gaussian Blur 2-0003=0"
```
